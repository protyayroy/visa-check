@php
    $active = 'about';
@endphp
@extends('front_end.layouts.main')

@section('content')
    About us
@endsection
