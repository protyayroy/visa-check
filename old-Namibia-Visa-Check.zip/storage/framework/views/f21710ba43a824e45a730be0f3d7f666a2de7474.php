<?php
    $active = 'dashboard';
?>

<?php $__env->startSection('title'); ?>
    Profile
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header main_header mt-3">
            <h4 class="text-center mb-0"><i class="fa-solid fa-user"></i> <?php echo e(auth()->user()->name); ?>

                Profile
            </h4>
        </div>
        <div class="card-body body-content">
            <div class="pt-3">
                <?php if(Session::has('success_message')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <strong>Success:</strong> <?php echo e(Session('success_message')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>
                <div class="row">
                    <div class="col-4">
                        <div class="row">
                            <div class="profile-image">
                                <?php if(!empty(auth()->user()->image)): ?>
                                    <img src="<?php echo e(url('file/admins/' . auth()->user()->image)); ?>"
                                        alt="<?php echo e(auth()->user()->image); ?>" class="img-fluid">
                                <?php else: ?>
                                    <img src="<?php echo e(url('file/dummy_image/person.webp')); ?>"
                                        alt="images/dummy_image/person.webp" class="img-fluid">
                                <?php endif; ?>
                                <?php if(!empty(auth()->user()->image)): ?>
                                    <div class="overlay text-center">
                                        <div class="image-button">
                                            <a href="<?php echo e(url('file/admins/' . auth()->user()->image)); ?>"
                                                class="btn btn-info mb-4">View
                                                Image</a>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="col-12 form_card mt-4">
                                <?php if($errors->any()): ?>
                                    <div class="alert alert-danger text-center">
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($error); ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php endif; ?>
                                <h4>Upload Profile Image</h4>
                                <form action="<?php echo e(route('profile.image.update')); ?>" enctype="multipart/form-data" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <label for="update_image">Choose Image:</label>
                                    <input type="file" name="update_image" id="update_image" class="form-control-file">
                                    <button class="btn btn-primary mt-2 float-right"><i class="fa-solid fa-rotate"></i>
                                        &nbsp; Update Image</button>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-8">
                        <a href="<?php echo e(route('profile.edit')); ?>" class="btn btn-info float-right mb-2"> Edit Profile &nbsp;
                            <i class="fa-sharp fa-solid fa-arrow-right"></i>
                        </a>
                        <div class="clearfix"></div>
                        <table class="table table-bordered">
                            <tr>
                                <th>Name:</th>
                                <td><?php echo e(auth()->user()->name); ?></td>
                            </tr>
                            <tr>
                                <th>Email:</th>
                                <td><?php echo e(auth()->user()->email); ?></td>
                            </tr>
                            <tr>
                                <th>Mobile:</th>
                                <td><?php echo e(auth()->user()->mobile); ?></td>
                            </tr>
                            <tr>
                                <th>Address:</th>
                                <td><?php echo e(auth()->user()->address); ?></td>
                            </tr>
                            
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\1New folder\Namibia-Visa-Check\resources\views/admin/profile/view_profile.blade.php ENDPATH**/ ?>