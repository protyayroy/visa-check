<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Namibia Visa | <?php echo $__env->yieldContent('title', 'Dashboard'); ?> </title>

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('backend')); ?>/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.2/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('backend')); ?>/vendors/feather/feather.css">
    <link rel="stylesheet" href="<?php echo e(asset('backend')); ?>/vendors/ti-icons/css/themify-icons.css">
    <link rel="stylesheet" href="<?php echo e(asset('backend')); ?>/vendors/ti-icons/css/themify-icons.css">
    <link rel="stylesheet" href="<?php echo e(asset('backend')); ?>/css/vertical-layout-light/style.css">

    <link rel="stylesheet" href="<?php echo e(asset('backend')); ?>/custom.css">
    <link rel="shortcut icon" href="<?php echo e(asset('backend')); ?>/images/favicon.png" />

</head>

<body>


    <div class="container-scroller">

        <?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="container-fluid page-body-wrapper">

            <?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="main-panel">

                <?php echo $__env->yieldContent('content'); ?>

                <?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            </div>
        </div>
    </div>

    <script src="<?php echo e(asset('backend')); ?>/vendors/js/vendor.bundle.base.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/vendors/chart.js/Chart.min.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/js/off-canvas.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/js/template.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/js/dashboard.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/js/Chart.roundedBarCharts.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="<?php echo e(asset('backend')); ?>/js/jquery-3.6.3.min.js"></script>
    
    <script src="https://cdn.datatables.net/1.13.2/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.2/js/dataTables.bootstrap4.min.js"></script>

    <script>
        $(document).ready(function() {
            $('#bootstrap_datatable').DataTable({
                scrollX: true,
            });
        });
    </script>

    <?php echo $__env->yieldContent('js'); ?>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\1New folder\Namibia-Visa-Check\resources\views/admin/layouts/layout.blade.php ENDPATH**/ ?>