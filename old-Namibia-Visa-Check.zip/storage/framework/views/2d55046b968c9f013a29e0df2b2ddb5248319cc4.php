<footer class="footer">
    <div class="d-sm-flex justify-content-center justify-content-sm-between">
      <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">© Copyright 2023 Reserved by Gunma Halal Food. </span>
      <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center"> Design and developed by<a href="https://softtech-it.com/" target="_blank"> SOFTTECH-IT </a> <i class="ti-heart text-danger ml-1"></i></span>
    </div>
  </footer>
<?php /**PATH C:\xampp\htdocs\1New folder\Namibia-Visa-Check\resources\views/admin/layouts/footer.blade.php ENDPATH**/ ?>