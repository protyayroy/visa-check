@extends('front_end.layouts.main')

@section('content')
    Contuct Us
@endsection
