<?php
    $active = 'application';
?>

<?php $__env->startSection('title'); ?>
    Application
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header main_header mt-3">
            <h4 class="text-center mb-0"><i class="fa-solid fa-user"></i> Visa Application
            </h4>
        </div>
        <div class="card-body body-content">
            <div class="pt-3">
                <?php if(Session::has('success_message')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <strong>Success:</strong> <?php echo e(Session('success_message')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>
                <table id="bootstrap_datatable" class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Nationality</th>
                            <th>Former Nationality</th>
                            <th>Country of Residence</th>
                            <th>Visa Consulate</th>
                            <th>Visa Submission Mode</th>
                            <th>Mobile No.</th>
                            <th>Date of Birth</th>
                            <th>E-mail</th>
                            <th>Sponsor</th>
                            <th>Documents</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->nationality); ?></td>
                                <td><?php echo e($item->former_nationality); ?></td>
                                <td><?php echo e($item->country_residence); ?></td>
                                <td><?php echo e($item->consulate); ?></td>
                                <td><?php echo e($item->submission_mode); ?></td>
                                <td><?php echo e($item->mobile); ?></td>
                                <td><?php echo e($item->date_of_birth); ?></td>
                                <td><?php echo e($item->email); ?></td>
                                <td><?php echo e($item->sponsor); ?></td>
                                <td>
                                    <a href="<?php echo e(url('documents/'.$item->document)); ?>" class="btn btn-info" target="_blank"><i class="fa-solid fa-file"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\1New folder\Namibia-Visa-Check\resources\views/admin/application/visa_application.blade.php ENDPATH**/ ?>