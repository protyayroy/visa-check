<nav class="sidebar sidebar-offcanvas" id="sidebar">
    <ul class="nav">
        <li class="nav-item <?php echo e($active == 'dashboard' ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">
                <i class="fa-solid fa-house"></i>
                <span class="menu-title">Dashboard</span>
            </a>
        </li>
        <li class="nav-item <?php echo e($active == 'application' ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('application')); ?>">
                <i class="fa-solid fa-house"></i>
                <span class="menu-title">Visa Application</span>
            </a>
        </li>
        <li class="nav-item <?php echo e($active == 'approve_list' ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('approve.list')); ?>">
                <i class="fa-solid fa-house"></i>
                <span class="menu-title">Visa Approved List</span>
            </a>
        </li>
        <li class="nav-item <?php echo e($active == 'add_approval' ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('create.approval')); ?>">
                <i class="fa-solid fa-house"></i>
                <span class="menu-title">Add Approval</span>
            </a>
        </li>
        
    </ul>
</nav>
<?php /**PATH C:\xampp\htdocs\1New folder\Namibia-Visa-Check\resources\views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>