<?php $__env->startSection('content'); ?>
    About us
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front_end.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\1New folder\Namibia-Visa-Check\resources\views/front_end/about.blade.php ENDPATH**/ ?>