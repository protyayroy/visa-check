


<img src="<?php echo e(asset('file/logo/logo.png')); ?>" alt="logo.png" style="height: 150px">
<?php /**PATH C:\xampp\htdocs\1New folder\Namibia-Visa-Check\resources\views/components/application-logo.blade.php ENDPATH**/ ?>