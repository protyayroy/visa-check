<nav class="navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
    <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
        <a class="navbar-brand brand-logo mr-5" href="<?php echo e(route('dashboard')); ?>"><img
                src="<?php echo e(url('file/logo/logo.png')); ?>" class="mr-2"
                alt="logo.png" /></a>

        <a class="navbar-brand brand-logo-mini" href="<?php echo e(route('dashboard')); ?>"><img
                src="<?php echo e(url('file/logo/logo.png')); ?>"
                alt="logo.png" /></a>
    </div>
    <div class="navbar-menu-wrapper d-flex align-items-center justify-content-end">
        <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
            <span class="icon-menu"></span>
        </button>
        <ul class="navbar-nav mr-lg-2">
            <li class="nav-item nav-search d-none d-lg-block">
            </li>
        </ul>
        <ul class="navbar-nav navbar-nav-right">
            <li class="nav-item nav-profile dropdown">
                <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown" id="profileDropdown">
                    <?php if(!empty(auth()->user()->image)): ?>
                        <img src="<?php echo e(url('file/admins/' . auth()->user()->image)); ?>" alt="<?php echo e(auth()->user()->image); ?>"
                            class="img-fluid">
                    <?php else: ?>
                        <img src="<?php echo e(url('file/dummy_image/person.webp')); ?>" alt="person.webp"
                            class="img-fluid">
                    <?php endif; ?>
                </a>
                <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="profileDropdown">
                    <a class="dropdown-item" href="<?php echo e(route('profile')); ?>">
                        <i class="ti-settings text-primary"></i>
                        Settings
                    </a>
                    

                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>">
                            <i class="ti-power-off text-primary"></i>
                            Logout
                        </a>
                </div>
            </li>
            <li class="nav-item custom">
                <ul>
                    <li>
                        <span>Mr. <?php echo e(auth()->user()->name); ?></span>
                    </li>
                </ul>
            </li>
        </ul>
        <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button"
            data-toggle="offcanvas">
            <span class="icon-menu"></span>
        </button>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\1New folder\Namibia-Visa-Check\resources\views/admin/layouts/header.blade.php ENDPATH**/ ?>